#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import os
from typing import Dict
from botbuilder.core.skills import BotFrameworkSkill


class DefaultConfig:
    """ Bot Configuration """

    PORT = 3978
    APP_ID = os.environ.get(
        "MicrosoftAppId", "2b352e51-c6a5-4bdd-932c-93b5dc474932"
    )
    APP_PASSWORD = os.environ.get(
        "MicrosoftAppPassword", "0cJSRYBR47~ZVh.1.Kjc48QeWwV5_T.uHc"
    )
    SKILL_HOST_ENDPOINT = "https://pythonparentbot.azurewebsites.net/api/skills"
    SKILLS = [
        {
            "id": "EchoSkillBot",
            "app_id": "b3b19e26-8d55-4e04-a10f-e35787162101",
            "skill_endpoint": "https://pythonskillbot.azurewebsites.net/api/messages",
        },
    ]

    # Callers to only those specified, '*' allows any caller.
    # Example: os.environ.get("AllowedCallers", ["54d3bb6a-3b6d-4ccd-bbfd-cad5c72fb53a"])
    ALLOWED_CALLERS = os.environ.get("AllowedCallers", ["*"])


class SkillConfiguration:
    SKILL_HOST_ENDPOINT = DefaultConfig.SKILL_HOST_ENDPOINT
    SKILLS: Dict[str, BotFrameworkSkill] = {
        skill["id"]: BotFrameworkSkill(**skill) for skill in DefaultConfig.SKILLS
    }

#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import os


class DefaultConfig:
    """ Bot Configuration """

    PORT = 39783
    APP_ID = os.environ.get(
        "MicrosoftAppId", "b3b19e26-8d55-4e04-a10f-e35787162101"
    )
    APP_PASSWORD = os.environ.get(
        "MicrosoftAppPassword", "rX-zvd-_8uajs_7_779~y0qqd10L_g9PVj"
    )

    # Callers to only those specified, '*' allows any caller.
    # Example: os.environ.get("AllowedCallers", ["aaaaaa-1111-1111-1111-aaaaaaaaaa"])
    ALLOWED_CALLERS = os.environ.get("AllowedCallers", ["*"])
